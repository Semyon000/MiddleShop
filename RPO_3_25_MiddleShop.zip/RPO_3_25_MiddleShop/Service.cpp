﻿#include "Service.hpp"
#include "Storage.hpp"

void Getline(std::wstring& str)
{
    std::getline(std::wcin, str, L'\n');
}

bool IsNumber(const std::wstring& str)
{
    if (str.size() <= 0 || str.size() >= 10)
    {
        std::wcout << L"Ошибка длины. Максимум 9 значное число\n\n";
        Sleep(1600);
        return false;
    }

    for (size_t i = 0; i < str.size(); i++)
    {
        if (!std::iswdigit(str[i]))
        {
            std::wcout << L"Введенные данные не являются числом\n\n";
            Sleep(1600);
            return false;
        }
    }

    return true;
}

void Err()
{
    std::wcout << L"Некорректный ввод! Повторите попытку\n\n";
    Sleep(1500);
}

bool IsDouble(const std::wstring& str)
{
    // допускаем цифры и один разделитель (точка или запятая), максимум 12 символов
    if (str.size() <= 0 || str.size() >= 13)
    {
        std::wcout << L"Ошибка длины. Максимум 12 символов\n\n";
        Sleep(1600);
        return false;
    }

    size_t separatorCount = 0;
    size_t digitCount = 0;
    for (size_t i = 0; i < str.size(); i++)
    {
        if (str[i] == L'.' || str[i] == L',')
        {
            separatorCount++;
        }
        else if (std::iswdigit(str[i]))
        {
            digitCount++;
        }
        else
        {
            std::wcout << L"Введенные данные не являются числом\n\n";
            Sleep(1600);
            return false;
        }
    }

    if (separatorCount > 1 || digitCount == 0)
    {
        std::wcout << L"Введенные данные не являются числом\n\n";
        Sleep(1600);
        return false;
    }

    return true;
}

double ToDouble(std::wstring str)
{
    for (size_t i = 0; i < str.size(); i++)
    {
        if (str[i] == L',')
        {
            str[i] = L'.';
        }
    }
    return std::stod(str);
}

bool IsSame(const std::wstring& name)
{
    // true - товар с таким названием уже есть на складе
    for (size_t i = 0; i < sizeSt; i++)
    {
        if (nameArr[i] == name)
        {
            std::wcout << L"Товар с таким названием уже существует!\n\n";
            Sleep(2000);
            return true;
        }
    }
    return false;
}
