﻿#ifndef _SERVICE_HPP_
#define _SERVICE_HPP_

#include <iostream>
#include <string>
#include <cstdlib>
#include <cwctype>
#include <Windows.h>
#include <iomanip>

void Getline(std::wstring& str);
bool IsNumber(const std::wstring& str);
void Err();
bool IsSame(const std::wstring& name);
bool IsDouble(const std::wstring& str);
double ToDouble(std::wstring str);

template <class ArrType>
void FillArray(ArrType* staticArr, ArrType* dynamicArr, size_t commonSize)
{
    for (size_t i = 0; i < commonSize; i++)
    {
        dynamicArr[i] = staticArr[i];
    }
}

#endif // !_SERVICE_HPP_
