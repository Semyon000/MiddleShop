﻿#include "Storage.hpp"

size_t sizeSt = 0;
size_t* idArr = nullptr;
std::wstring* nameArr = nullptr;
size_t* countArr = nullptr;
double* priceArr = nullptr;

bool isStorageCreated = false;

size_t maxStorageSize = 2000;
size_t currentStorageSize = 0;

void CreateStorage(int mode)
{
    if (mode == 0)
    {
        const size_t staticSize = 10;

        size_t idArrStatic[staticSize]{ 1,2,3,4,5,6,7,8,9,10 };
        std::wstring nameArrStatic[staticSize]
        {
            L"Букет \"101 роза\"", L"Тюльпаны белые (15 шт.)",
            L"Пионы розовые (7 шт.)", L"Хризантема кустовая", L"Эустома в букете",
            L"Орхидея фаленопсис в горшке", L"Гербера микс (10 шт.)",
            L"Подсолнухи (5 шт.)", L"Лилия белая ароматная",
            L"Композиция \"Лепесток\" в шляпной коробке"
        };
        size_t countArrStatic[staticSize]{ 14,30,9,18,23,7,22,40,10,3 };
        double priceArrStatic[staticSize]{ 7990.0, 1450.0, 3200.0, 390.0, 1250.0, 2400.0,
            980.0, 750.0, 520.0, 4900.0 };

        sizeSt = staticSize;
        idArr = new size_t[sizeSt];
        nameArr = new std::wstring[sizeSt];
        countArr = new size_t[sizeSt];
        priceArr = new double[sizeSt];

        FillArray(idArrStatic, idArr, sizeSt);
        FillArray(nameArrStatic, nameArr, sizeSt);
        FillArray(countArrStatic, countArr, sizeSt);
        FillArray(priceArrStatic, priceArr, sizeSt);

        currentStorageSize = 0;
        for (size_t i = 0; i < sizeSt; i++)
        {
            currentStorageSize += countArr[i];
        }

        isStorageCreated = true;
    }
}

void ShowStorage(int mode)
{
    // mode 0 - весь склад (ID, название, кол-во, цена) с паузой
    // mode 1 - пополнение товаров (ID, название, кол-во + заполненность склада)
    // mode 2 - списание товаров (ID, название, кол-во + заполненность склада)
    // mode 3 - изменение цены (ID, название, цена)
    // mode 4 - переименование (ID, название)
    // mode 5 - добавление нового товара (весь склад + заполненность склада)
    system("cls");

    std::wcout << L"\n\n\t\t\t";
    switch (mode)
    {
    case 1: std::wcout << L"Пополнение товаров \"Лепесток\""; break;
    case 2: std::wcout << L"Списание товаров \"Лепесток\""; break;
    case 3: std::wcout << L"Изменение цены \"Лепесток\""; break;
    case 4: std::wcout << L"Переименование \"Лепесток\""; break;
    case 5: std::wcout << L"Добавление нового товара \"Лепесток\""; break;
    default: std::wcout << L"Товары \"Лепесток\""; break;
    }
    std::wcout << L"\n\n";

    // шапка таблицы
    std::wcout << L"ID\t" << std::left << std::setw(40) << L"Название товара";
    if (mode == 0 || mode == 5)
    {
        std::wcout << L"\t\t" << L"Кол-во\t" << L"Цена";
    }
    else if (mode == 1 || mode == 2)
    {
        std::wcout << L"\t\t" << L"Кол-во";
    }
    else if (mode == 3)
    {
        std::wcout << L"\t\t" << L"Цена";
    }
    std::wcout << L"\n\n";

    // строки таблицы
    for (size_t i = 0; i < sizeSt; i++)
    {
        std::wcout << idArr[i] << L"\t" << std::left << std::setw(40) << nameArr[i];
        if (mode == 0 || mode == 5)
        {
            std::wcout << L"\t\t" << countArr[i] << L"\t" << priceArr[i];
        }
        else if (mode == 1 || mode == 2)
        {
            std::wcout << L"\t\t" << countArr[i];
        }
        else if (mode == 3)
        {
            std::wcout << L"\t\t" << priceArr[i];
        }
        std::wcout << L"\n";
    }
    std::wcout << L"\n\n";

    if (mode == 1 || mode == 2 || mode == 5)
    {
        std::wcout << L"Заполненность склада " << currentStorageSize << L" из "
            << maxStorageSize << L"\n\n";
    }

    if (mode == 0)
    {
        system("pause");
    }
}

void AddProduct()
{
    std::wstring chooseId, chooseCount, choose;

    while (true)
    {
        ShowStorage(1);

        std::wcout << L"Введите ID товара или \"exit\" для выхода: ";
        Getline(chooseId);

        if (chooseId == L"exit" || chooseId == L"Exit")
        {
            std::wcout << L"Завершение операции пополнения товара\n\n";
            Sleep(1500);
            return;
        }
        else if (IsNumber(chooseId))
        {
            int id = std::stoi(chooseId) - 1;
            if (id < 0 || static_cast<size_t>(id) > sizeSt - 1)
            {
                Err();
            }
            else
            {
                std::wcout << L"Введите кол-во товара для пополнения: ";
                Getline(chooseCount);
                if (IsNumber(chooseCount))
                {
                    size_t count = std::stoull(chooseCount);
                    if (count == 0 || count > maxStorageSize - currentStorageSize)
                    {
                        std::wcout << L"Некорректное кол-во! На складе осталось "
                            << maxStorageSize - currentStorageSize << L" свободных мест\n\n";
                        Sleep(2000);
                    }
                    else
                    {
                        while (true)
                        {
                            system("cls");
                            std::wcout << nameArr[id] << L"\t" << countArr[id] << L" -----> "
                                << countArr[id] + count << L"\n\n";
                            std::wcout << L"Подтвердить?\n1 - Да\n2 - Нет\n\nВвод: ";
                            Getline(choose);

                            if (choose == L"1")
                            {
                                std::wcout << L"Товар успешно пополнен\n\n";
                                countArr[id] += count;
                                currentStorageSize += count;
                                Sleep(1500);
                                break;
                            }
                            else if (choose == L"2")
                            {
                                std::wcout << L"Отмена пополнения " << nameArr[id] << L"\n";
                                Sleep(1500);
                                break;
                            }
                            else
                            {
                                Err();
                            }
                        }
                    }
                }
            }
        }
    }
}

void RemoveProduct()
{
    std::wstring chooseId, chooseCount, choose;

    while (true)
    {
        ShowStorage(2);

        std::wcout << L"Введите ID товара или \"exit\" для выхода: ";
        Getline(chooseId);

        if (chooseId == L"exit" || chooseId == L"Exit")
        {
            std::wcout << L"Завершение операции списания товара\n\n";
            Sleep(1500);
            return;
        }
        else if (IsNumber(chooseId))
        {
            int id = std::stoi(chooseId) - 1;
            if (id < 0 || static_cast<size_t>(id) > sizeSt - 1)
            {
                Err();
            }
            else
            {
                std::wcout << L"Введите кол-во товара для списания: ";
                Getline(chooseCount);
                if (IsNumber(chooseCount))
                {
                    size_t count = std::stoull(chooseCount);
                    if (count == 0 || count > countArr[id])
                    {
                        std::wcout << L"Некорректное кол-во! На складе имеется \"" << nameArr[id]
                            << L"\": " << countArr[id] << L" шт.\n\n";
                        Sleep(2000);
                    }
                    else
                    {
                        while (true)
                        {
                            system("cls");
                            std::wcout << nameArr[id] << L"\t" << countArr[id] << L" -----> "
                                << countArr[id] - count << L"\n\n";
                            std::wcout << L"Подтвердить?\n1 - Да\n2 - Нет\n\nВвод: ";
                            Getline(choose);

                            if (choose == L"1")
                            {
                                std::wcout << L"Товар успешно списан\n\n";
                                countArr[id] -= count;
                                currentStorageSize -= count;
                                Sleep(1500);
                                break;
                            }
                            else if (choose == L"2")
                            {
                                std::wcout << L"Отмена списания " << nameArr[id] << L"\n";
                                Sleep(1500);
                                break;
                            }
                            else
                            {
                                Err();
                            }
                        }
                    }
                }
            }
        }
    }
}

void ChangePrice()
{
    std::wstring chooseId, choosePrice, choose;

    while (true)
    {
        ShowStorage(3);

        std::wcout << L"Введите ID товара или \"exit\" для выхода: ";
        Getline(chooseId);

        if (chooseId == L"exit" || chooseId == L"Exit")
        {
            std::wcout << L"Завершение операции изменения цены\n\n";
            Sleep(1500);
            return;
        }
        else if (IsNumber(chooseId))
        {
            int id = std::stoi(chooseId) - 1;
            if (id < 0 || static_cast<size_t>(id) > sizeSt - 1)
            {
                Err();
            }
            else
            {
                std::wcout << L"Введите новую цену товара: ";
                Getline(choosePrice);
                if (IsDouble(choosePrice))
                {
                    double price = ToDouble(choosePrice);
                    if (price <= 0)
                    {
                        std::wcout << L"Некорректная цена! Цена должна быть больше нуля\n\n";
                        Sleep(2000);
                    }
                    else
                    {
                        while (true)
                        {
                            system("cls");
                            std::wcout << nameArr[id] << L"\t" << priceArr[id] << L" -----> "
                                << price << L"\n\n";
                            std::wcout << L"Подтвердить?\n1 - Да\n2 - Нет\n\nВвод: ";
                            Getline(choose);

                            if (choose == L"1")
                            {
                                std::wcout << L"Цена успешно изменена\n\n";
                                priceArr[id] = price;
                                Sleep(1500);
                                break;
                            }
                            else if (choose == L"2")
                            {
                                std::wcout << L"Отмена изменения цены " << nameArr[id] << L"\n";
                                Sleep(1500);
                                break;
                            }
                            else
                            {
                                Err();
                            }
                        }
                    }
                }
            }
        }
    }
}

void ChangeStorage()
{
    std::wstring chooseSize, choose;

    while (true)
    {
        system("cls");
        std::wcout << L"\n\n\t\tВместимость склада\n\n";
        std::wcout << L"Максимальная вместимость: " << maxStorageSize << L"\n";
        std::wcout << L"Занято: " << currentStorageSize << L"\n";
        std::wcout << L"Свободно: " << maxStorageSize - currentStorageSize << L"\n\n";

        std::wcout << L"Введите новую вместимость или \"exit\" для выхода: ";
        Getline(chooseSize);

        if (chooseSize == L"exit" || chooseSize == L"Exit")
        {
            std::wcout << L"Завершение операции изменения вместимости\n\n";
            Sleep(1500);
            return;
        }
        else if (IsNumber(chooseSize))
        {
            size_t newSize = std::stoull(chooseSize);
            if (newSize == 0 || newSize < currentStorageSize)
            {
                std::wcout << L"Некорректная вместимость! На складе уже занято "
                    << currentStorageSize << L" мест\n\n";
                Sleep(2000);
            }
            else
            {
                while (true)
                {
                    system("cls");
                    std::wcout << L"Вместимость склада\t" << maxStorageSize << L" -----> "
                        << newSize << L"\n\n";
                    std::wcout << L"Подтвердить?\n1 - Да\n2 - Нет\n\nВвод: ";
                    Getline(choose);

                    if (choose == L"1")
                    {
                        std::wcout << L"Вместимость склада успешно изменена\n\n";
                        maxStorageSize = newSize;
                        Sleep(1500);
                        return;
                    }
                    else if (choose == L"2")
                    {
                        std::wcout << L"Отмена изменения вместимости\n";
                        Sleep(1500);
                        break;
                    }
                    else
                    {
                        Err();
                    }
                }
            }
        }
    }
}

void AddNewProduct()
{
    std::wstring chooseName, chooseCount, choosePrice, choose;

    while (true)
    {
        ShowStorage(5);

        std::wcout << L"Введите название нового товара или \"exit\" для выхода: ";
        Getline(chooseName);

        if (chooseName == L"exit" || chooseName == L"Exit")
        {
            std::wcout << L"Завершение операции добавления нового товара\n\n";
            Sleep(1500);
            return;
        }
        else if (chooseName.empty() || chooseName.size() > 40)
        {
            std::wcout << L"Некорректное название! От 1 до 40 символов\n\n";
            Sleep(2000);
            continue;
        }

        // проверка: такой товар уже есть?
        if (IsSame(chooseName))
        {
            continue;
        }

        std::wcout << L"Введите кол-во товара (свободно мест: "
            << maxStorageSize - currentStorageSize << L"): ";
        Getline(chooseCount);
        if (!IsNumber(chooseCount))
        {
            continue;
        }
        size_t count = std::stoull(chooseCount);
        if (count > maxStorageSize - currentStorageSize)
        {
            std::wcout << L"Некорректное кол-во! На складе осталось "
                << maxStorageSize - currentStorageSize << L" свободных мест\n\n";
            Sleep(2000);
            continue;
        }

        std::wcout << L"Введите цену товара: ";
        Getline(choosePrice);
        if (!IsDouble(choosePrice))
        {
            continue;
        }
        double price = ToDouble(choosePrice);
        if (price <= 0)
        {
            std::wcout << L"Некорректная цена! Цена должна быть больше нуля\n\n";
            Sleep(2000);
            continue;
        }

        while (true)
        {
            system("cls");
            std::wcout << L"Новый товар:\n\n";
            std::wcout << L"Название: " << chooseName << L"\n";
            std::wcout << L"Кол-во: " << count << L"\n";
            std::wcout << L"Цена: " << price << L"\n\n";
            std::wcout << L"Подтвердить?\n1 - Да\n2 - Нет\n\nВвод: ";
            Getline(choose);

            if (choose == L"1")
            {
                // создаём массивы на 1 больше и копируем в них старые данные
                size_t newSize = sizeSt + 1;
                size_t* newIdArr = new size_t[newSize];
                std::wstring* newNameArr = new std::wstring[newSize];
                size_t* newCountArr = new size_t[newSize];
                double* newPriceArr = new double[newSize];

                FillArray(idArr, newIdArr, sizeSt);
                FillArray(nameArr, newNameArr, sizeSt);
                FillArray(countArr, newCountArr, sizeSt);
                FillArray(priceArr, newPriceArr, sizeSt);

                // записываем новый товар в конец
                newIdArr[sizeSt] = sizeSt + 1;
                newNameArr[sizeSt] = chooseName;
                newCountArr[sizeSt] = count;
                newPriceArr[sizeSt] = price;

                // удаляем старые массивы и подменяем указатели
                delete[] idArr;
                delete[] nameArr;
                delete[] countArr;
                delete[] priceArr;

                idArr = newIdArr;
                nameArr = newNameArr;
                countArr = newCountArr;
                priceArr = newPriceArr;

                sizeSt = newSize;
                currentStorageSize += count;

                std::wcout << L"Товар успешно добавлен\n\n";
                Sleep(1500);
                break;
            }
            else if (choose == L"2")
            {
                std::wcout << L"Отмена добавления " << chooseName << L"\n";
                Sleep(1500);
                break;
            }
            else
            {
                Err();
            }
        }
    }
}

void ChangeProductName()
{
    std::wstring chooseId, chooseName, choose;
    int id = 0;
    while (true)
    {
        ShowStorage(4);

        std::wcout << L"Введите ID товара или \"exit\" для выхода: ";
        Getline(chooseId);

        if (chooseId == L"exit" || chooseId == L"Exit")
        {
            std::wcout << L"Завершение операции переименования товара\n\n";
            Sleep(1500);
            return;
        }
        else if (IsNumber(chooseId))
        {
            id = std::stoi(chooseId) - 1;
            if (id < 0 || static_cast<size_t>(id) > sizeSt - 1)
            {
                Err();
            }
            else
            {
                std::wcout << L"Введите новое название товара: ";
                Getline(chooseName);
                if (chooseName.empty() || chooseName.size() > 40)
                {
                    std::wcout << L"Некорректное название! От 1 до 40 символов\n\n";
                    Sleep(2000);
                }
                else if (!IsSame(chooseName))
                {
                    while (true)
                    {
                        system("cls");
                        std::wcout << nameArr[id] << L" -----> " << chooseName << L"\n\n";
                        std::wcout << L"Подтвердить?\n1 - Да\n2 - Нет\n\nВвод: ";
                        Getline(choose);

                        if (choose == L"1")
                        {
                            std::wcout << L"Товар успешно переименован\n\n";
                            nameArr[id] = chooseName;
                            Sleep(1500);
                            break;
                        }
                        else if (choose == L"2")
                        {
                            std::wcout << L"Отмена переименования " << nameArr[id] << L"\n";
                            Sleep(1500);
                            break;
                        }
                        else
                        {
                            Err();
                        }
                    }
                }
            }
        }
    }
}
