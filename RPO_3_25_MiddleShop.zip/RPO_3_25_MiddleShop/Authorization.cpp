﻿#include "Authorization.hpp"
#include "Storage.hpp"

// меню склада (пока вместо TO_DO)
static void StorageMenu()
{
    std::wstring choose;
    while (true)
    {
        system("cls");
        std::wcout << L"\n\n\t\tМеню склада\n\n";
        std::wcout << L"1 - Показать склад\n"
            << L"2 - Пополнить товар\n"
            << L"3 - Списать товар\n"
            << L"4 - Изменить цену товара\n"
            << L"5 - Изменить вместимость склада\n"
            << L"6 - Добавить новый товар\n"
            << L"7 - Переименовать товар\n"
            << L"0 - Выйти из аккаунта\n\nВвод: ";
        Getline(choose);

        if (choose == L"1")
        {
            ShowStorage();
        }
        else if (choose == L"2")
        {
            AddProduct();
        }
        else if (choose == L"3")
        {
            RemoveProduct();
        }
        else if (choose == L"4")
        {
            ChangePrice();
        }
        else if (choose == L"5")
        {
            ChangeStorage();
        }
        else if (choose == L"6")
        {
            AddNewProduct();
        }
        else if (choose == L"7")
        {
            ChangeProductName();
        }
        else if (choose == L"0")
        {
            return;
        }
        else
        {
            Err();
        }
    }
}

void Start()
{
    while (true)
    {
        if (Login())
        {
            if (currentStatus == L"SuperAdmin")
            {
                StorageMenu(); // TO_DO
            }
            else if (currentStatus == L"Admin")
            {
                StorageMenu(); // TO_DO
            }
            else if (currentStatus == L"User")
            {
                // TO_DO
            }
            else
            {

            }
        }
        else
        {
            return;
        }
    }
}

bool Login()
{
    std::wstring login, pass;
    while (true)
    {
        system("cls");
        std::wcout << L"\n\n\n\t\tДобро пожаловать!\n";
        std::wcout << L"\n\n\t  Цветочный магазин \"Лепесток\"\n\n";
        std::wcout << L"Введите логин или \"exit\" для выхода: ";
        Getline(login);
        if (login == L"exit" || login == L"Exit")
        {
            return false;
        }
        else
        {
            std::wcout << L"Введите пароль: ";
            Getline(pass);
            for (size_t i = 0; i < userSize; i++)
            {
                if (login == loginArr[i] && pass == passArr[i])
                {
                    std::wcout << L"\nДобро пожаловать " << loginArr[i] << L"\n";
                    std::wcout << L"Ваш уровень доступа: " << statusArr[i] << L"\n";
                    Sleep(1500);
                    currentId = userIdArr[i];
                    currentStatus = statusArr[i];
                    return true;
                }
            }
            std::wcout << L"Неверный логин или пароль.Повторите попытку\n\n";
            Sleep(1500);
        }
    }
}